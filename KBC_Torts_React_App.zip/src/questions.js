const QUESTIONS = [
  { id:1, q:"Which article of the Constitution of India is most commonly invoked for state liability in cases of unsafe roads?", opts:["Article 14","Article 19","Article 21","Article 370"], a:"c" },
  { id:2, q:"The landmark case establishing state liability for negligence in maintenance of public roads is:", opts:["Kasturi Lal v. State of UP","State of Rajasthan v. Vidhyawati","Rudul Shah v. State of Bihar","Bhim Singh v. State of J&K"], a:"b" },
  { id:3, q:"Duty of care in road infrastructure projects applies to:", opts:["Only government officials","Only contractors","All parties involved in design, construction, and maintenance","Only road users"], a:"c" },
  { id:4, q:"Under tort law, a breach of duty leading to foreseeable harm is called:", opts:["Nuisance","Strict liability","Negligence","Vicarious liability"], a:"c" },
  { id:5, q:"The Consumer Protection Act, 2019 imposes strict liability on:", opts:["Only car dealers","Only government authorities","Manufacturers, assemblers, and dealers","Only mechanics"], a:"c" },
  { id:6, q:"Vicarious liability means:", opts:["You are liable only for your personal acts","Employers are liable for employees’ acts","Only the government is liable","Liability depends only on written contracts"], a:"b" },
  { id:7, q:"Recall of defective vehicles in India is governed by:", opts:["Section 304A, IPC","Section 7, CPA 2019","Section 110A, Motor Vehicles Act","Article 226, Constitution"], a:"c" },
  { id:8, q:"Which type of petition is commonly filed for unsafe public roads?", opts:["PIL under Article 32/226","RTI application","Criminal complaint","Private contract suit"], a:"a" },
  { id:9, q:"The Supreme Court in S. Rajaseekaran v. Union of India focused on:", opts:["Environmental safety","Pedestrian safety and road audits","Vehicle emission standards","Criminal sanctions"], a:"b" },
  { id:10, q:"Who is typically responsible for potholes in city roads?", opts:["State transport office","Municipality/local body","Car manufacturer","Consumer forum"], a:"b" },
  { id:11, q:"Municipal liability for road hazards is based on:", opts:["Contract law only","Common law negligence","Product liability law","Criminal law only"], a:"b" },
  { id:12, q:"Product liability in the US and EU compared to India is generally:", opts:["Always based on criminal law","Less strict than India’s","Based on strict and no-fault regimes","Not applicable to vehicles"], a:"c" },
  { id:13, q:"NHTSA is a vehicle recall authority in:", opts:["Australia","China","United States","United Kingdom"], a:"c" },
  { id:14, q:"In a PPP (public-private partnership) road contract, risk is usually allocated through:", opts:["Insurance only","Penalty clauses","Indemnity clauses and contract provisions","Orally"], a:"c" },
  { id:15, q:"The best method to prevent liability for latent construction defects is:", opts:["Ignore post-completion defects","Maintenance contract and safety audits","Only rely on penalties","Use only most expensive contractors"], a:"b" },
  { id:16, q:"Who adjudicates Motor Accident Claims in India?", opts:["District Civil Court","MACT","Supreme Court","NHAI"], a:"b" },
  { id:17, q:"No-fault compensation for road accident victims is provided under:", opts:["Section 166, Motor Vehicles Act","Section 161, Motor Vehicles Act","Section 164, Motor Vehicles Act","Section 304A, IPC"], a:"c" },
  { id:18, q:"Section 304A of the IPC covers:", opts:["Causing death by rash or negligent act","Contractual liability","Corporate criminal liability","Product warranty"], a:"a" },
  { id:19, q:"Who sets the standards for road construction materials in India?", opts:["BIS","Supreme Court","Indian Medical Association","National Consumer Forum"], a:"a" },
  { id:20, q:"The Motor Vehicles (Amendment) Act, 2019 brought significant reform to:", opts:["Education","Vehicle emissions","Road user liability, vehicle recalls, and compensation","Maritime law"], a:"c" },
  { id:21, q:"Which Indian authority issues national road safety guidelines?", opts:["NITI Aayog","Ministry of Road Transport & Highways","Indian Railways","Reserve Bank of India"], a:"b" },
  { id:22, q:"A road safety audit primarily helps:", opts:["Only after accidents","Prevent defects and minimize liability","Prosecute employees","None of the above"], a:"b" },
  { id:23, q:"Smart infrastructure technologies for road safety include:", opts:["Intelligent Transport Systems (ITS)","Handheld stop signs","Paper checklists only","None of the above"], a:"a" },
  { id:24, q:"Institutional accountability for road safety is ensured through:", opts:["Out-of-court settlements","Independent audits, tribunal oversight, and NHAI guidelines","Social media campaigns only","Exemption from all laws"], a:"b" },
  { id:25, q:"The main aim of policy reforms in road safety liability is to:", opts:["Minimize punishment for authorities","Shift entire burden to users","Enhance prevention, compensation, and accountability","Promote only road expansion"], a:"c" }
];

export default QUESTIONS;
