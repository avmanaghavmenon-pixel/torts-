import React, { useEffect, useState, useRef } from 'react';
import QuestionCard from './components/QuestionCard';
import LifelinesPanel from './components/LifelinesPanel';
import Scoreboard from './components/Scoreboard';
import QUESTIONS from './questions';
import './App.css';

export default function App(){ 
  const [cur, setCur] = useState(0);
  const [answers, setAnswers] = useState({});
  const [lifelines, setLifelines] = useState({ fifty:false, poll:false, phone:false });
  const [adminReveal, setAdminReveal] = useState(false);
  const [bgMusic, setBgMusic] = useState(false);
  const [autoNext, setAutoNext] = useState(false);
  const [timerEnabled, setTimerEnabled] = useState(false);
  const audioRefs = useRef({});
  const [finished, setFinished] = useState(false);

  useEffect(()=>{
    audioRefs.current.intro = new Audio('/assets/intro.mp3');
    audioRefs.current.lock = new Audio('/assets/lock.mp3');
    audioRefs.current.correct = new Audio('/assets/correct.mp3');
    audioRefs.current.wrong = new Audio('/assets/wrong.mp3');
    audioRefs.current.bg = new Audio('/assets/bg.mp3');
    audioRefs.current.bg.loop = true;
    audioRefs.current.bg.volume = 0.18;
  },[]);

  useEffect(()=>{
    if(bgMusic){
      audioRefs.current.bg.play().catch(()=>{});
    } else {
      try{ audioRefs.current.bg.pause(); audioRefs.current.bg.currentTime = 0; }catch(e){}
    }
  },[bgMusic]);

  function handleAnswer(qid, letter){
    setAnswers(prev=>({ ...prev, [qid]: letter }));
    if(QUESTIONS[cur].a === letter){ try{ audioRefs.current.correct.play().catch(()=>{}); }catch(e){} }
    else try{ audioRefs.current.wrong.play().catch(()=>{}); }catch(e){}
    if(autoNext){ setTimeout(()=>{ if(cur < QUESTIONS.length-1) setCur(c=>c+1); else setFinished(true); },800); }
  }

  function use5050(){ if(lifelines.fifty) return; setLifelines(l => ({ ...l, fifty:true })); }
  function usePoll(){ if(lifelines.poll) return; setLifelines(l=>({...l, poll:true})); }
  function usePhone(){ if(lifelines.phone) return; setLifelines(l=>({...l, phone:true})); }

  function next(){ if(cur < QUESTIONS.length-1) setCur(c=>c+1); else setFinished(true); }
  function prev(){ if(cur>0) setCur(c=>c-1); }
  function restart(){ setAnswers({}); setCur(0); setLifelines({ fifty:false, poll:false, phone:false }); setFinished(false); setAdminReveal(false); }

  return (
    <div className="app-root">
      <header className="app-header">
        <div className="brand">
          <div className="logo">KBC</div>
          <div>
            <h1>KBC — Torts Edition</h1>
            <div className="subtitle">25 Questions • Host the show — two contestants</div>
          </div>
        </div>
        <div className="controls-top">
          <label><input type="checkbox" checked={bgMusic} onChange={e=>setBgMusic(e.target.checked)} /> Background music</label>
          <label><input type="checkbox" checked={autoNext} onChange={e=>setAutoNext(e.target.checked)} /> Auto-next</label>
          <label><input type="checkbox" checked={timerEnabled} onChange={e=>setTimerEnabled(e.target.checked)} /> Timer</label>
        </div>
      </header>

      <main className="main-grid">
        <section className="stage">
          <QuestionCard
            question={QUESTIONS[cur]}
            qNo={cur+1}
            total={QUESTIONS.length}
            onAnswer={handleAnswer}
            selected={answers[QUESTIONS[cur].id]}
            adminReveal={adminReveal}
            lifelinesUsed={lifelines}
            onUse5050={use5050}
            onUsePoll={usePoll}
            onUsePhone={usePhone}
            audioRefs={audioRefs}
            timerEnabled={timerEnabled}
          />

          <div className="nav-row">
            <button className="btn ghost" onClick={prev}>Previous</button>
            <button className="btn ghost" onClick={next}>Next</button>
            <button className="btn primary" onClick={()=>{ setAdminReveal(r=>!r) }}>{adminReveal? 'Admin: ON' : 'Admin Reveal'}</button>
            <button className="btn" onClick={()=>{ try{ audioRefs.current.lock.play().catch(()=>{}); }catch(e){} }}>Lock Sound</button>
            <button className="btn ghost" onClick={()=>{ try{ audioRefs.current.intro.play().catch(()=>{}); }catch(e){} }}>Play Intro</button>
            <button className="btn ghost" onClick={()=>restart()}>Restart</button>
          </div>

        </section>

        <aside className="sidebar">
          <Scoreboard questions={QUESTIONS} answers={answers} />

          <LifelinesPanel
            lifelines={lifelines}
            on5050={use5050}
            onPoll={usePoll}
            onPhone={usePhone}
          />

          <div className="panel">
            <button className="btn ghost" onClick={()=>{
              const rows = [['QNo','Question','Selected','Correct','Result']];
              QUESTIONS.forEach((q,i)=>{
                const sel = answers[q.id] ? answers[q.id].toUpperCase() : '';
                const cor = q.a.toUpperCase();
                const res = answers[q.id] === q.a ? 'Correct' : (answers[q.id]? 'Incorrect' : 'Unanswered');
                rows.push([i+1, q.q, sel, cor, res]);
              });
              const csv = rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
              const blob = new Blob([csv], {type:'text/csv'});
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a'); a.href = url; a.download = 'kbc_results.csv'; a.click(); URL.revokeObjectURL(url);
            }}>Export CSV</button>
          </div>

        </aside>
      </main>

      <footer className="footer">Built for classroom presentation • Deploy to CodeSandbox or Netlify for hosting</footer>
    </div>
  );
}
