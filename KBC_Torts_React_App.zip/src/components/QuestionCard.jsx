import React, { useEffect, useState } from 'react';
export default function QuestionCard({ question, qNo, total, onAnswer, selected, adminReveal, lifelinesUsed, onUse5050, onUsePoll, onUsePhone, audioRefs, timerEnabled }){
  const [disabled, setDisabled] = useState([]);
  const [poll, setPoll] = useState(null);
  const [phoneSuggest, setPhoneSuggest] = useState(null);
  const letters = ['a','b','c','d'];

  useEffect(()=>{
    setDisabled([]);
    setPoll(null);
    setPhoneSuggest(null);
  },[question.id]);

  function handleChoose(letter){
    onAnswer(question.id, letter);
  }

  function handle5050(){
    if(lifelinesUsed.fifty) return;
    const inc = letters.filter(l => l !== question.a);
    shuffleArray(inc);
    const toRemove = inc.slice(0,2);
    setDisabled(toRemove);
    onUse5050();
  }

  function handlePoll(){
    if(lifelinesUsed.poll) return;
    const baseCorrect = 55 + Math.floor(Math.random()*21);
    let remaining = 100 - baseCorrect;
    const other = letters.filter(l=> l !== question.a);
    const p = [];
    for(let i=0;i<other.length;i++){ if(i === other.length-1) { p.push(remaining) } else { const v = Math.floor(Math.random()*(remaining+1)); p.push(v); remaining -= v } }
    const percentages = [0,0,0,0];
    const correctIdx = letters.indexOf(question.a);
    percentages[correctIdx] = baseCorrect;
    let j=0;
    for(let i=0;i<4;i++){ if(i===correctIdx) continue; percentages[i] = p[j++] }
    setPoll(percentages);
    onUsePoll();
  }

  function handlePhone(){ if(lifelinesUsed.phone) return; const roll = Math.random(); let suggestion = roll < 0.7 ? question.a : letters.filter(l=>l!==question.a)[Math.floor(Math.random()*3)]; setPhoneSuggest(suggestion); onUsePhone(); }

  return (
    <div className="card">
      <div className="q-header">
        <div className="q-meta">Question {qNo} / {total}</div>
      </div>
      <div className="q-body">
        <div className="q-text">{question.q}</div>
        <div className="opts">
          {question.opts.map((opt, i)=>{
            const letter = letters[i];
            const isDisabled = disabled.includes(letter);
            const isSelected = selected === letter;
            const correct = adminReveal ? (question.a === letter) : false;
            return (
              <button key={i} className={`opt ${isDisabled? 'disabled':''} ${isSelected? 'selected':''} ${correct? 'correct':''}`} onClick={()=>handleChoose(letter)} disabled={isDisabled}>
                <div className="opt-left">{String.fromCharCode(65+i)}</div>
                <div className="opt-text">{opt}</div>
              </button>
            );
          })}
        </div>

        <div className="lifeline-row">
          <button className={`btn small ${lifelinesUsed.fifty? 'used':''}`} onClick={handle5050} disabled={lifelinesUsed.fifty}>50-50</button>
          <button className={`btn small ${lifelinesUsed.poll? 'used':''}`} onClick={handlePoll} disabled={lifelinesUsed.poll}>Audience Poll</button>
          <button className={`btn small ${lifelinesUsed.phone? 'used':''}`} onClick={handlePhone} disabled={lifelinesUsed.phone}>Phone a Friend</button>
        </div>

        {poll && (
          <div className="poll-anim">
            {poll.map((p,i)=> (
              <div key={i} className="poll-row">
                <div className="poll-label">{String.fromCharCode(65+i)}</div>
                <div className="poll-bar"><div className="poll-fill" style={{width: p + '%'}}>{p}%</div></div>
              </div>
            ))}
          </div>
        )}

        {phoneSuggest && (
          <div className="phone-suggest">Phone suggests: <strong>{phoneSuggest.toUpperCase()}</strong></div>
        )}

      </div>
    </div>
  );
}

function shuffleArray(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]] } return a }
