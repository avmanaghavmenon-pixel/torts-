import React from 'react';
export default function Scoreboard({ questions, answers }){
  const total = questions.length;
  const answered = Object.keys(answers).length;
  const correct = questions.reduce((acc,q)=> acc + (answers[q.id] === q.a ? 1:0),0);
  return (
    <div className="panel scoreboard">
      <h3>Scoreboard</h3>
      <div className="stat">Score: <strong>{correct} / {total}</strong></div>
      <div className="stat">Answered: <strong>{answered}</strong></div>
      <div className="stat">Correct: <strong>{correct}</strong></div>
    </div>
  );
}
