import React from 'react';
export default function LifelinesPanel({ lifelines, on5050, onPoll, onPhone }){
  return (
    <div className="panel lifelines-panel">
      <h3>Lifelines</h3>
      <div className="lifelines-list">
        <button className={`btn ${lifelines.fifty? 'used':''}`} onClick={on5050} disabled={lifelines.fifty}>50-50</button>
        <button className={`btn ${lifelines.poll? 'used':''}`} onClick={onPoll} disabled={lifelines.poll}>Audience</button>
        <button className={`btn ${lifelines.phone? 'used':''}`} onClick={onPhone} disabled={lifelines.phone}>Phone a Friend</button>
      </div>
    </div>
  );
}
